Go to output -> test_gui -> test_gui.exe

Layout sucks, but will probably need to rearrange everything later anyway, so no need to think to much about it now.
What are your thoughts on next steps?

- Write data to file/save variables and collect them
- Just continue to classes/import class level table
- Write things more readable in GUI(it should be possible, although not easy, to use bold, underlines etc.)
- Go to next page: feats, pointbuy, background,etc

- Feel free to comment on how nice it is, that there are pictures...

